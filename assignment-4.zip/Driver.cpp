// Example Driver File
// Author: David Stabler

#include "PriorityString.h"
#include <iostream>
#include <string>
#include <queue>
#include <functional>

using namespace std;	// required for string

//Note! O(N^2). We must copy first, and then empty Queue.
template <typename T, typename Sequence, typename Compare>
ostream& operator<< (ostream& out, const priority_queue<T, Sequence, Compare>& pq)
{
	//make a copy so that this is not destructive
	priority_queue<T, Sequence, Compare> copy = pq;
	//TODO ensure that the comparator is preserved in the copy!
	
	// output the queue
	while(!copy.empty())
	{
		out << copy.top() << endl;
		copy.pop();
	}
	return out;
}

//pre-condition: pq1 and pq2 are defined with the same comparator (not explicitly enforced)
//post-condition: pq1 and pq2 are combined using the comparator from pq1
//this operation will take O(N^3). The copy takes O(N), the push and pop will take O(N), and then a copy is performed upon return
//because we must pass by value.
//This operation is not commutative due to the nature of the heap.
template <typename T,typename Sequence, typename Compare>
priority_queue<T,Sequence,Compare> operator+(const priority_queue<T,Sequence,Compare>& pq1, const priority_queue<T,Sequence,Compare>& pq2)
{
	priority_queue<T, Sequence, Compare> sum = pq1;
	priority_queue<T, Sequence, Compare> copy = pq2;
	while(!copy.empty())
	{
		sum.push(copy.top());
		copy.pop();
	}
	
	return sum;
}

template <typename T>
void clear(priority_queue<T>& pq)
{
	while (!pq.empty())
	{
		pq.pop();
	}
}

void main()
{

	priority_queue<
		PriorityString,
		vector<PriorityString>,
		greater<PriorityString>
	> pq1;

	string i="hi there";
 	PriorityString ps("String with Priority 5", 5);
	pq1.push(ps);
 	PriorityString ps2("String with Priority 4", 4);
	pq1.push(ps2);
	pq1.push(PriorityString("String with Priority 3", 3) );

	//false(0) then true(1)
	cout << (ps < ps2) << endl;
	cout << (ps > ps2) << endl;

	cout << pq1.size() << endl;

	while ( ! pq1.empty() )
	{
		cout <<  pq1.top() << endl;
		pq1.pop();
	}

	
	priority_queue<
		PriorityString,
		vector<PriorityString>,
		less<PriorityString>
	> PQ;

	PQ.push( PriorityString("Test String 1", 1) );
	PQ.push( ps );
	PQ.push( PriorityString("Test String 2", 2) );

	priority_queue<
		PriorityString,
		vector<PriorityString>,
		less<PriorityString>
	> PQ2;


	PQ2.push( PriorityString("Quick", 7));
	PQ2.push( PriorityString("Fox", 6));
	PQ2.push( PriorityString("The", 2));
	PQ2.push( PriorityString("Lazy", 1));
	PQ2.push( PriorityString("Jumps", 4));
	PQ2.push( PriorityString("Dog"));
	PQ2.push( PriorityString("Brown", 7));
	PQ2.push( PriorityString("Over", 4));
	PQ2.push( PriorityString("The", 9));
	PQ2.push( PriorityString("."));

	cout << i << endl;
	cout << ps << endl;
	cout << PQ << endl;
	cout << PQ2 << endl;

	//testing commutative property of + and verify the order theory
	priority_queue<PriorityString> PQ3;
	PQ3 = PQ + PQ2;
	cout << PQ3 << endl;

	clear(PQ3);

	PQ3 = PQ2 + PQ;
	cout << PQ3 << endl;

	clear(PQ2);
	PQ2.push(PriorityString("The", 0));
	PQ2.push(PriorityString("Quick", 0));
	PQ2.push(PriorityString("Brown", 0));
	PQ2.push(PriorityString("Fox", 0));
	PQ2.push(PriorityString("Jumps", 0));
	PQ2.push(PriorityString("Over", 0));
	PQ2.push(PriorityString("The", 0));
	PQ2.push(PriorityString("Lazy", 0));
	PQ2.push(PriorityString("Dog", 0));
	PQ2.push(PriorityString(".",0));
	cout << PQ2 << endl;

	PQ2.push(PriorityString("Test", 0));
	cout << PQ2 << endl;

	PQ2.push(PriorityString("Test", 0));
	cout << PQ2 << endl;

	//test greater than comparator for max heap and operator+ 
	priority_queue<
		PriorityString,
		vector<PriorityString>,
		greater<PriorityString>
	> PQ4;
	PQ4.push(PriorityString("10", 10));
	PQ4.push(PriorityString("2", 2));
	PQ4.push(PriorityString("4", 4));
	PQ4.push(PriorityString("1", 1));

		priority_queue<
		PriorityString,
		vector<PriorityString>,
		greater<PriorityString>
	> PQ5 =	PQ4 + PQ4;
	cout << PQ5 << endl;
}